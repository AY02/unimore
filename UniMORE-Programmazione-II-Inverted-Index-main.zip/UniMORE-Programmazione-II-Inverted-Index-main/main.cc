/** @mainpage
* Il programma carica da file le parole e per ciascuna parola vengono salvati il numero di documenti in cui e' presente e i loro rispettivi identificativi. 
* Inoltre, e' possibile aggiornare le parole inserendo il nome del file contenente il nuovo documento con le parole al suo interno. 
* Infine, vengono queste due parole in input e verranno stampati gli identificativi dei documenti che contengono entrambe.\n
* Link alla funzione stampa: \ref stampa
*/


#include <iostream>
#include <fstream>
using namespace std;


#include "tipo.h"
#include "liste.h"
#include "parola.h"
#include <cstring>


/* PUNTO 1 */
parola *load(int &n) {
  ifstream f_in("inverted.txt");
  f_in >> n;
  parola *words = new parola[n];
  for(int i=0; i<n; i++) {
    f_in >> words[i].p;
    f_in >> words[i].n_doc;
    words[i].l = NULL;
    int tmp;
    for(int j=0; j<words[i].n_doc; j++) {
      f_in >> tmp;
      words[i].l = insert_elem(words[i].l, new_elem(tmp));
    }
  }
  f_in.close();
  return words;
}

/** @brief Funzione stampa.
* Prende in ingresso un array dinamico di parole e il numero di parole. \n
* Stampa tutte le parole e in generale tutta la lista.
*/
void stampa(parola *words, int n) {
  cout << "Ci sono in totale " << n << " parole." << endl;
  for(int i=0; i<n; i++) {
    cout << "Parola: " << words[i].p << endl;
    cout << "Numero di documenti in cui e' presente: " << words[i].n_doc << endl;
    cout << "Lista degli identificativi dei documenti:" << endl;
    lista tmp = words[i].l;
    while(tmp != NULL) {
      print(head(tmp));
      cout << " -> ";
      tmp = tail(tmp);
    }
    cout << "NULL" << endl << endl;
  }
}

/* PUNTO 2 */
bool is_new_word(parola *words, int n, char *word) {
  for(int i=0; i<n; i++)
    if(strcmp(words[i].p, word) == 0)
      return false;
  return true;
}

void re_alloc_words(parola *&words, int &n, char *new_word) {
  parola *new_words = new parola[n+1];
  for(int i=0; i<n; i++) {
    strcpy(new_words[i].p, words[i].p);
    new_words[i].n_doc = words[i].n_doc;
    new_words[i].l = words[i].l;
  }
  strcpy(new_words[n].p, new_word);
  new_words[n].n_doc = 0;
  new_words[n].l = NULL;
  delete words;
  words = new_words;
  n++;
}

void update(parola *&words, char *filename, int &n) {
  ifstream f_in(filename);
  int new_doc_id;
  f_in >> new_doc_id;
  char tmp_word[80];
  while(f_in >> tmp_word) {
    if(is_new_word(words, n, tmp_word))
      re_alloc_words(words, n, tmp_word);
    for(int i=0; i<n; i++)
      if(
        strcmp(words[i].p, tmp_word) == 0 &&
        search(words[i].l, new_doc_id) == NULL
      ) {
        words[i].l = insert_elem(words[i].l, new_elem(new_doc_id));
        words[i].n_doc++;
      }
  }
}

/* PUNTO 3*/
void and_words(parola *words, char *word1, char *word2, int n) {
  lista list1 = NULL;
  lista list2 = NULL;
  int i = 0;
  while(list1 == NULL || list2 == NULL) {
    if(strcmp(words[i].p, word1) == 0)
      list1 = words[i].l;
    if(strcmp(words[i].p, word2) == 0)
      list2 = words[i].l;
    i++;
  }
  cout << "Documenti che contengono sia " << word1 << " che " << word2 << ":" << endl;
  while(list1 != NULL) {
    if(search(list2, head(list1)) != NULL) {
      print(head(list1));
      cout << " ";
    }
    list1 = tail(list1);
  }
  cout << endl;
}

/* MAIN */
int main() {
  /* INIZIO PUNTO 1 */
  int n;
  parola *words = load(n);
  cout << "Inverted Index caricato dal file:" << endl;
  stampa(words, n);
  /* FINE PUNTO 1 */

  /* INIZIO PUNTO 2 */
  char filename[256+1];
  cout << "Inserisci il nome del file con cui vuoi aggiornare le parole: ";
  cin >> filename;
  update(words, filename, n);
  cout << "Inverted Index aggiornato:" << endl;
  stampa(words, n);
  /* FINE PUNTO 2 */

  /* INIZIO PUNTO 3 */
  cout << "Inserisci la prima parola: ";
  char word1[80];
  cin >> word1;
  cout << "Inserisci la seconda parola: ";
  char word2[80];
  cin >> word2;
  and_words(words , word1, word2, n);
  /* FINE PUNTO 3* */
  return 0;
}