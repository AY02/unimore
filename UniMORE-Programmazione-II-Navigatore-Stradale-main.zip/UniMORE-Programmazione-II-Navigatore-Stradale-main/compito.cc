#include <iostream>
using namespace std;
#include <fstream>
#include <cfloat>
#include "tipo.h"
#include "codap.h"
#include "grafo.h"


/* Inizio Punto 1 */
graph load(int &dim, tipo_inf *&nomi) {
    ifstream f_in("strade");
    f_in >> dim;
    graph grafo = new_graph(dim);
    nomi = new tipo_inf[dim];
    f_in.ignore(1); /* Ignora il carattere '\n' successivo all'input della dimensione del grafo */
    for(int i=0; i<dim; i++) {
        nomi[i] = new_inf_elem(256+1);
        f_in.getline(nomi[i], 256+1);
    }
    int u, v;
    float w;
    while(f_in >> u >> v >> w)
        add_arc(grafo, u, v, w);
    f_in.close();
    return grafo;
}
void stampa(graph grafo, char **nomi) {
    for(int i=0; i<get_dim(grafo); i++) {
        cout << "(" << i+1 << ", ";
        print(nomi[i]);
        cout << "): ";
        adj_list tmp = get_adjlist(grafo, i+1);
        while(tmp != NULL) {
            cout << "(" << get_adjnode(tmp) << ", ";
            print(nomi[get_adjnode(tmp)-1]);
            cout << ", " << get_adjweight(tmp) << ") -> ";
            tmp = get_nextadj(tmp);
        }
        cout << "NULL" << endl;
    }
}
/* Fine Punto 1   */

/* Inizio Punto 2 */
void dijkstra(graph grafo, int s, float *&dest, int *&parent) {
    int dim = get_dim(grafo);
    dest = new float[dim];
    parent = new int[dim];
    for(int i=0; i<dim; i++) {
        dest[i] = FLT_MAX;
        parent[i] = -1;
    }
    dest[s-1] = 0;
    codap queue = NULL;
    for(int i=0; i<dim; i++)
        queue = enqueue(queue, i, dest[i]);
    while(!isEmpty(queue)) {
        int u = dequeue(queue);
        adj_list vicini = get_adjlist(grafo, u+1);
        while(vicini != NULL) {
            int v = get_adjnode(vicini);
            float w_u_v = get_adjweight(vicini);
            if(dest[v-1] > dest[u] + w_u_v) {
                dest[v-1] = dest[u] + w_u_v;
                parent[v-1] = u + 1;
            }
            queue = Decrease_Priority(queue, v-1, dest[v-1]);
            vicini = get_nextadj(vicini);
        }
    }
}
int *calcolo(graph grafo, int s, int d, float &peso_percorso, int &dim_percorso) {
    float *dest = NULL;
    int *parent = NULL;
    dijkstra(grafo, s, dest, parent);
    peso_percorso = dest[d-1];
    dim_percorso = 0;
    if(peso_percorso == FLT_MAX) /* Non esiste il percorso da s a d */
        return NULL;
    int *percorso = new int[get_dim(grafo)];
    int tmp = d;
    while(tmp != -1) {
        percorso[dim_percorso] = tmp;
        tmp = parent[tmp-1];
        dim_percorso++;
    }
    return percorso;
}
/* Fine Punto 2   */

/* Inizio Punto 3 */
void ricalcola(graph grafo, int s, int d) {
    float *dest = NULL;
    int *parent = NULL;
    dijkstra(grafo, s, dest, parent);
    float peso_percorso;
    int dim_percorso;
    int *percorso = calcolo(grafo, s, d, peso_percorso, dim_percorso);
    if(percorso == NULL) {
        cout << "Il percorso non esiste." << endl;
        return;
    }
    int dim = get_dim(grafo);
    int *scelte = new int[dim];
    int tempo = 0;
    int tmp = s;
    while(percorso[dim_percorso-2-tempo] != d) {
        int n_scelte = 0;
        for(int i=0; i<dim; i++)
            if(parent[i] == tmp) {
                scelte[n_scelte] = i+1;
                n_scelte++;
            }
        int scelta;
        cout << "Ti trovi in " << tmp << ". Scegli tra ";
        for(int i=0; i<n_scelte; i++)
            cout << scelte[i] << " ";
        cout << "--> ";
        cin >> scelta;
        if(scelta == percorso[dim_percorso-2-tempo]) {
            cout << "Hai scelto un incrocio ottimo." << endl;
            tempo++;
        }
        else {
            cout << "Hai scelto un incrocio non ottimo." << endl;
            dijkstra(grafo, scelta, dest, parent);
            percorso = calcolo(grafo, scelta, d, peso_percorso, dim_percorso);
            if(percorso == NULL) {
                cout << "L'incrocio che hai scelto non porta alla destinazione." << endl;
                return;
            }
            tempo = 0;
        }
        tmp = scelta;
    }
    cout << "Hai finito." << endl;
}
/* Fine Punto 3   */

int main() {

    /* Inizio Punto 1 */
    int dim;
    tipo_inf *nomi = NULL;
    graph grafo = load(dim, nomi);
    stampa(grafo, nomi);
    /* Fine Punto 1   */

    /* Inizio Punto 2 */
    int s, d;
    cout << "Inserisci l'incrocio di partenza: ";
    cin >> s;
    if(s <= 0 || s > dim) {
        cerr << "Non esiste tale sorgente." << endl;
        return -1;
    }
    cout << "Inserisci l'incrocio di destinazione: ";
    cin >> d;
    if(d <= 0 || d > dim) {
        cerr << "Non esiste tale destinazione." << endl;
        return -2;
    }
    float peso_percorso;
    int dim_percorso;
    int *percorso = calcolo(grafo, s, d, peso_percorso, dim_percorso);
    if(percorso == NULL)
        cout << "Il percorso non esiste." << endl;
    else {
        for(int i=dim_percorso-1; i>=0; i--)
            cout << percorso[i] << " -> ";
        cout << "NULL" << endl;
        cout << "Peso totale: " << peso_percorso << endl;
    }
    /* Fine Punto 2   */

   /* Inizio Punto 3 */
    cout << "Inserisci l'incrocio di partenza: ";
    cin >> s;
    if(s <= 0 || s > dim) {
        cerr << "Non esiste tale sorgente." << endl;
        return -1;
    }
    cout << "Inserisci l'incrocio di destinazione: ";
    cin >> d;
    if(d <= 0 || d > dim) {
        cerr << "Non esiste tale destinazione." << endl;
        return -2;
    }
    ricalcola(grafo, s, d);
    /* Fine Punto 3   */

    return 0;

}