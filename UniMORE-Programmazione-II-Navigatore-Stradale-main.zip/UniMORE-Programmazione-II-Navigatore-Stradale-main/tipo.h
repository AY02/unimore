/*******************************/
/* HEADER MODULO "tipo" */
/*******************************/



typedef char* tipo_inf;

tipo_inf new_inf_elem(int);
int compare(tipo_inf,tipo_inf);
void copy(tipo_inf&,tipo_inf);
void print(tipo_inf);
